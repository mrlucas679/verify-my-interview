const { json, readBody } = require("../jsonResponse");

module.exports = async function (context, req) {
  const { chatLocal, withLogsOnStderr } = require("../bundle.cjs");
  const body = readBody(req);
  const caseContext = body && body.caseContext;
  const messages = body && Array.isArray(body.messages) ? body.messages : [];

  try {
    context.res = json(200, await withLogsOnStderr(() => chatLocal(caseContext, messages)));
  } catch (error) {
    context.log.error(`Chat failed: ${error instanceof Error ? error.message : String(error)}`);
    context.res = json(500, { error: "The detective could not reply right now." });
  }
};
