const { json, readBody } = require("../jsonResponse");

module.exports = async function (context, req) {
  const { analyzeEvidenceLocal, MAX_LOCAL_EVIDENCE_CHARS, withLogsOnStderr } = require("../bundle.cjs");
  const body = readBody(req);
  const evidence = body && typeof body.evidence === "string" ? body.evidence : "";

  if (!evidence.trim()) {
    context.res = json(400, { error: 'Field "evidence" must be a non-empty string.' });
    return;
  }

  if (evidence.length > MAX_LOCAL_EVIDENCE_CHARS) {
    context.res = json(400, {
      error: `Evidence is too long (${evidence.length} chars). Limit is ${MAX_LOCAL_EVIDENCE_CHARS}.`
    });
    return;
  }

  try {
    context.res = json(200, await withLogsOnStderr(() => analyzeEvidenceLocal(evidence)));
  } catch (error) {
    context.log.error(`Analyze failed: ${error instanceof Error ? error.message : String(error)}`);
    context.res = json(500, { error: "Internal server error" });
  }
};
