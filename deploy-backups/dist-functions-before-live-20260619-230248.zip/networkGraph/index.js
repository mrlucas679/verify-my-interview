const { json } = require("../jsonResponse");

module.exports = async function (context, req) {
  const { networkGraphLocal, withLogsOnStderr } = require("../bundle.cjs");
  const limit = Number(req.query && req.query.limit);
  context.res = json(200, await withLogsOnStderr(() => networkGraphLocal({
    limit: Number.isFinite(limit) ? limit : undefined
  })));
};
