const { securityHeaders } = require("./headers");

function json(status, body) {
  return {
    status,
    headers: securityHeaders("application/json; charset=utf-8"),
    body: JSON.stringify(body)
  };
}

function readBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.rawBody === "string" && req.rawBody.trim()) {
    try {
      return JSON.parse(req.rawBody);
    } catch {
      return null;
    }
  }
  return null;
}

function errorStatus(error) {
  return Number.isInteger(error && error.clientStatus) ? error.clientStatus : 500;
}

module.exports = { errorStatus, json, readBody };
