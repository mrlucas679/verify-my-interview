const { json } = require("../jsonResponse");
const { firstFile } = require("../multipart");

module.exports = async function (context, req) {
  const { uploadDocumentLocal, withLogsOnStderr } = require("../bundle.cjs");
  const file = firstFile(req, "file");
  if (!file.file) {
    context.res = json(file.status || 400, { error: file.error || "file is required" });
    return;
  }

  try {
    context.res = json(200, await withLogsOnStderr(() => uploadDocumentLocal(file.file, file.filename)));
  } catch (error) {
    context.log.error(`Upload failed: ${error instanceof Error ? error.message : String(error)}`);
    context.res = json(500, { error: "Could not read that file." });
  }
};
