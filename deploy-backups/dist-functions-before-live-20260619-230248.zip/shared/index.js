const { errorStatus, json } = require("../jsonResponse");

module.exports = async function (context, req) {
  const { getSharedReportLocal, withLogsOnStderr } = require("../bundle.cjs");

  try {
    context.res = json(200, {
      result: await withLogsOnStderr(() => getSharedReportLocal(req.params.id || ""))
    });
  } catch (error) {
    const status = errorStatus(error);
    context.res = json(status, {
      error: error instanceof Error && status < 500 ? error.message : "Failed to load shared report"
    });
  }
};
