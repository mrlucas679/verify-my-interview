const { json } = require("../jsonResponse");

module.exports = async function (context) {
  context.res = json(200, {
    service: "Verify My Interview",
    endpoints: {
      "POST /analyze": "Investigate job/interview evidence",
      "POST /report": "File a community scam report",
      "POST /share": "Save a finished report result for sharing",
      "GET /shared/:id": "Load a previously shared report result",
      "POST /upload": "Extract text from a screenshot or document",
      "POST /transcribe": "Transcribe an audio recording",
      "GET /health": "Subsystem status"
    }
  });
};
