const { json } = require("../jsonResponse");
const { firstFile } = require("../multipart");

module.exports = async function (context, req) {
  const { transcribeAudioLocal, withLogsOnStderr } = require("../bundle.cjs");
  const file = firstFile(req, "audio");
  if (!file.file) {
    context.res = json(file.status || 400, { error: file.error || "audio file is required" });
    return;
  }

  try {
    context.res = json(200, await withLogsOnStderr(() => transcribeAudioLocal(file.file, file.filename)));
  } catch (error) {
    context.log.error(`Transcribe failed: ${error instanceof Error ? error.message : String(error)}`);
    context.res = json(500, { error: "Could not transcribe that audio." });
  }
};
