const { json } = require("../jsonResponse");

module.exports = async function (context) {
  const { networkStatsLocal, withLogsOnStderr } = require("../bundle.cjs");
  context.res = json(200, await withLogsOnStderr(() => networkStatsLocal()));
};
