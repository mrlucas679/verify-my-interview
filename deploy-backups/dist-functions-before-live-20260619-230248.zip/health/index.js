const { json } = require("../jsonResponse");

module.exports = async function (context) {
  const { healthSnapshot } = require("../bundle.cjs");
  context.res = json(200, healthSnapshot());
};
