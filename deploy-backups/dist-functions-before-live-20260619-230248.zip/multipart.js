function header(req, name) {
  const headers = req.headers || {};
  return headers[name] || headers[name.toLowerCase()] || headers[name.toUpperCase()] || "";
}

function multipartBoundary(contentType) {
  const match = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || "");
  return match ? (match[1] || match[2]).trim() : "";
}

function bodyBuffer(req) {
  if (Buffer.isBuffer(req.body)) return req.body;
  if (typeof req.rawBody === "string") return Buffer.from(req.rawBody, "binary");
  return Buffer.alloc(0);
}

function firstFile(req, fieldName) {
  const boundary = multipartBoundary(header(req, "content-type"));
  if (!boundary) return { status: 415, error: "Expected multipart/form-data upload." };
  const body = bodyBuffer(req);
  const marker = Buffer.from(`--${boundary}`);
  let cursor = body.indexOf(marker);
  while (cursor !== -1) {
    const partStart = cursor + marker.length + 2;
    const next = body.indexOf(marker, partStart);
    if (next === -1) break;
    const splitAt = body.indexOf(Buffer.from("\r\n\r\n"), partStart);
    if (splitAt === -1 || splitAt > next) break;
    const rawHeaders = body.subarray(partStart, splitAt).toString("latin1");
    let contentEnd = next;
    if (body[contentEnd - 2] === 13 && body[contentEnd - 1] === 10) contentEnd -= 2;
    const disposition = rawHeaders
      .split(/\r\n/)
      .find((line) => line.toLowerCase().startsWith("content-disposition:")) || "";
    if (disposition.includes(`name="${fieldName}"`) && /filename="/i.test(disposition)) {
      const filename = (/filename="([^"]*)"/i.exec(disposition) || [])[1] || "upload.bin";
      return { file: body.subarray(splitAt + 4, contentEnd), filename };
    }
    cursor = next;
  }
  return { status: 400, error: "file is required" };
}

module.exports = { firstFile };
