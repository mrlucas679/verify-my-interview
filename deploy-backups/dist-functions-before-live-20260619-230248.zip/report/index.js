const { errorStatus, json, readBody } = require("../jsonResponse");

module.exports = async function (context, req) {
  const { submitReportLocal, withLogsOnStderr } = require("../bundle.cjs");
  const body = readBody(req);

  try {
    context.res = json(201, await withLogsOnStderr(() => submitReportLocal(body || {})));
  } catch (error) {
    const status = errorStatus(error);
    if (status >= 500) {
      context.log.error(`Report failed: ${error instanceof Error ? error.message : String(error)}`);
    }
    context.res = json(status, {
      error: error instanceof Error && status < 500 ? error.message : "Failed to file report"
    });
  }
};
