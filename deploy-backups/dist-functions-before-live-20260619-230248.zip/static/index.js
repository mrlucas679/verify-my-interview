const fs = require("fs");
const path = require("path");
const { securityHeaders } = require("../headers");

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
  ".ico": "image/x-icon"
};

function clean(raw) {
  const value = raw && String(raw).trim() ? String(raw) : "index.html";
  const normalized = path.normalize(value.split("?")[0]).replace(/^(\.\.[/\\])+/, "");
  return normalized === "." || normalized === path.sep ? "index.html" : normalized;
}

module.exports = async function (context, req) {
  const root = path.join(process.cwd(), "public");
  const requested = clean(req.params.path);
  const candidate = path.resolve(root, requested);
  const rootPrefix = root.endsWith(path.sep) ? root : `${root}${path.sep}`;
  const safeCandidate = candidate.startsWith(rootPrefix) ? candidate : path.join(root, "index.html");
  const file = fs.existsSync(safeCandidate) && fs.statSync(safeCandidate).isFile()
    ? safeCandidate
    : path.join(root, "index.html");
  const ext = path.extname(file).toLowerCase();

  context.res = {
    status: 200,
    headers: securityHeaders(TYPES[ext] || "application/octet-stream", {
      "cache-control": ext === ".html" ? "no-store" : "public, max-age=31536000, immutable"
    }),
    body: fs.readFileSync(file)
  };
};
